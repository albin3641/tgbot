500 - InternalServerError
-------------------------

.. csv-table::
    :file: ../../../../compiler/errors/source/500_INTERNAL_SERVER_ERROR.tsv
    :delim: tab
    :header-rows: 1