401 - Unauthorized
------------------

.. csv-table::
    :file: ../../../../compiler/errors/source/401_UNAUTHORIZED.tsv
    :delim: tab
    :header-rows: 1
